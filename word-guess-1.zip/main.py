import random
word_list = ["banana", "apple", "orange"]
guess = input("type a letter. ").lower()
#TODO-1 - random pick a word from word_list
pick_word = random.choice(word_list)
print(pick_word)
#TODO-2 - compare guess letter with picked word
# for letter in pick_word:
#   if guess == letter:
#     print("right")
#   else:
#     print("wrong")
# TODO 3: replace the correct letter in the position
display = []
for _ in range(len(pick_word)):
  display += "_"

# TODO 4: replace letter in position
for position in range(len(pick_word)):
  letter = pick_word[position]
  if guess == letter:
    display[position] = letter

print(display)
